package com.example.lab05;

public class Products {
    public int productID;
    public String productName;
    public String orderDate;
    public String manufacturer;
}
